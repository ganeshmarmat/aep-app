import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quation-info',
  templateUrl: './quation-info.component.html',
  styleUrls: ['./quation-info.component.css']
})
export class QuationInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
