import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direct-supplier-quotation',
  templateUrl: './direct-supplier-quotation.component.html',
  styleUrls: ['./direct-supplier-quotation.component.css']
})
export class DirectSupplierQuotationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
