import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direct-supplier-purchase-order',
  templateUrl: './direct-supplier-purchase-order.component.html',
  styleUrls: ['./direct-supplier-purchase-order.component.css']
})
export class DirectSupplierPurchaseOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
