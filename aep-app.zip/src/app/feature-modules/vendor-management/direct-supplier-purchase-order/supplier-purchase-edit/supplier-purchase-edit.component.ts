import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-purchase-edit',
  templateUrl: './supplier-purchase-edit.component.html',
  styleUrls: ['./supplier-purchase-edit.component.css']
})
export class SupplierPurchaseEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
