import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-of-material',
  templateUrl: './bill-of-material.component.html',
  styleUrls: ['./bill-of-material.component.css']
})
export class BillOfMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
