import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-stock',
  templateUrl: './material-stock.component.html',
  styleUrls: ['./material-stock.component.css']
})
export class MaterialStockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
