import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warehouse-transfer',
  templateUrl: './warehouse-transfer.component.html',
  styleUrls: ['./warehouse-transfer.component.css']
})
export class WarehouseTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
