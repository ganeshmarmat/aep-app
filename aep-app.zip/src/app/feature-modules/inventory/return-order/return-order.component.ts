import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-order',
  templateUrl: './return-order.component.html',
  styleUrls: ['./return-order.component.css']
})
export class ReturnOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
