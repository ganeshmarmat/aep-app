import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-returns',
  templateUrl: './store-returns.component.html',
  styleUrls: ['./store-returns.component.css']
})
export class StoreReturnsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
