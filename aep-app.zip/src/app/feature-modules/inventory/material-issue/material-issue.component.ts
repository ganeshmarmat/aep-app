import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-issue',
  templateUrl: './material-issue.component.html',
  styleUrls: ['./material-issue.component.css']
})
export class MaterialIssueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
