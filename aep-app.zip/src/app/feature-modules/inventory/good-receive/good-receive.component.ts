import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-good-receive',
  templateUrl: './good-receive.component.html',
  styleUrls: ['./good-receive.component.css']
})
export class GoodReceiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
