import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation-control',
  templateUrl: './navigation-control.component.html',
  styleUrls: ['./navigation-control.component.css']
})
export class NavigationControlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
