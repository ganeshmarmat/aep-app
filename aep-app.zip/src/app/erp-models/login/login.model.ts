export class user{
    name:string
    password:string
}